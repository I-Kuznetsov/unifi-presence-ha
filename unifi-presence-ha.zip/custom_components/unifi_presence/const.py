DOMAIN = "unifi_presence"
